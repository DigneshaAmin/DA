﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace DealeRun_TrainsRoute
{
    // Distance Finder Class will store all the routes info and will have all the methods needed to calculate.
    public class DistanceFinder  
    {
        // routesList will store all the paths and distance. it is of List type of Route Class
        private List<Routes> routesList = new List<Routes>();
        
        public void AddRoutes(Routes routes)
        {
            routesList.Add(routes);
        }

        // Method overloading to find route between two stations
        public int FindRouteDistance(char st1,char st2)
        {
            int d1;
            d1 = FindDist(st1, st2);
            if (d1 <= 0)
            {
                return 0;
            }
            else
            {
                return d1;
            }
        }

        // Method overloading to find route between three stations

        public int FindRouteDistance(char st1, char st2, char st3)
        {
            int d1;
            int d2;
            d1 = FindDist(st1, st2);
            d2 = FindDist(st2, st3);
            // Return 0 if path not found
            if ((d1 <= 0) || (d2 <= 0))
            {
                return 0;
            }
            else 
                return d1+d2;
            
        }

        // Method overloading to find route between Five stations
        public int FindRouteDistance(char st1, char st2, char st3,char st4, char st5)
        {
            int d1;
            int d2;
            int d3;
            int d4;

            d1 = FindDist(st1, st2);
            d2 = FindDist(st2, st3);
            d3 = FindDist(st3, st4);
            d4 = FindDist(st4, st5);
            // Return 0 if path not found
            if ((d1 <= 0) || (d2 <= 0) || (d3 <= 0) || (d4 <= 0))
                return 0;
            else 
            {
                return d1 + d2 + d3 + d4;
            }
        }

        // private method to find distance between two stations. it will return -1 if path is not found
        private int FindDist(char Startst, char Endst)
        {
            int d = -1;
            
            foreach (Routes r1 in routesList)
            {
                if ((r1.FromStation == Startst) && (r1.ToStation == Endst))
                {
                    d = r1.Distance;
                    break;
                }
                               
            }
            return d;
        }

        // This method will find all the Routes between two stations and also keep track of the number of stops it made.

        public int RouteCounter(char startst, char endst, ref int stCnt)
        {
            char Nextst;
            int cnt=0;
            //stCnt = 0;

            foreach (Routes r1 in routesList)
            {
                if (r1.FromStation == startst)
                {
                    Nextst = r1.ToStation;
                    stCnt = stCnt + 1;
                    if (Nextst != endst)
                    {
                        cnt = cnt + RouteCounter(Nextst, endst, ref stCnt);
                    }
                    else
                    {

                        if (stCnt <= 3)
                        {
                            stCnt = 0;
                            return 1;
                        }
                        else
                        {
                            stCnt = 0;
                            return 0;
                        }
                    }
                }
            }
            return cnt;
        }

        // will be counting the distance between two stations. 
        // This will be looping through all the routes
        public int DistanceCounter(char startst, char endst, ref int distCnt)
        {
            char Nextst;
            int cnt = 0;

            foreach (Routes r1 in routesList)
            {
                if (r1.FromStation == startst)
                {
                    Nextst = r1.ToStation;
                    distCnt = distCnt + r1.Distance;
                    if (Nextst != endst)
                    {
                        cnt = cnt + DistanceCounter(Nextst, endst, ref distCnt);
                    }
                    else
                    {

                        if (distCnt <= 30)
                        {
                            distCnt = 0;
                            return 1;
                        }
                        else
                        {
                            distCnt = 0;
                            return 0;
                        }
                    }
                }
            }
            return cnt;
        }
        //public int StopsCounter(char startst, char endst)
        //{
        //    char Nextst;
        //    int cnt = 0;
        //   // int stopcount = 0;

        //    foreach (Routes r1 in routesList)
        //    {
        //        //stopCount = 0;
        //        if (r1.FromStation == startst)
        //        {
        //            stopCount = stopCount + 1;
        //            Nextst = r1.ToStation;
        //            if (Nextst != endst)
        //                cnt = cnt + StopsCounter(Nextst, endst);
        //            else
        //            {
        //                if (stopCount < 4)
        //                {
        //                    cnt = cnt + StopsCounter(Nextst, endst);
        //                }
        //                else
        //                {
        //                    if (stopCount == 4)
        //                    { stopCount = 0; return 1; }
        //                    else
        //                    { stopCount = 0; return 0; }
        //                }
        //            }
        //        }
        //    }
        //    return cnt;
        //}

    }
}