﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;

namespace DealeRun_TrainsRoute
{
    public partial class Trains_Schedule : System.Web.UI.Page
    {
        int lngErrorNumber;

        protected void Page_Load(object sender, EventArgs e)
        {
            btnCalc.Click += new EventHandler(this.btnCalc_Click);
        }

        void btnCalc_Click(Object sender, EventArgs e)
        {
            string strRouteText;


            char chst1;
            char chst2;
            string stdis;
            int intdis;
            string str2;

            int dist;
            int cnt=0;

            tbloutput.Visible = true;
            
            DistanceFinder df = new DistanceFinder();
            try
            {

                //Stack<string> strSingleRoute = new Stack<string>();
                strRouteText = txtRoute.Text;
                // splitting string to separate individual Route info
                string[] strSingleRoute = Regex.Split(strRouteText, @",");

                // looping through each string to separate Routeinfo
                foreach (string str in strSingleRoute)
                {
                    // removing extra space from string and ending if any 
                    str2 = str.Trim();

                    // if string is greater than 3 then the distance might be greater than 9
                    if (str2.Count() >= 3)
                    {
                        chst1 = str2.ElementAt(0);// First character is From Station
                        chst2 = str2.ElementAt(1);// Second character is To Station
                        stdis = str2.Substring(2);// Third character is Distance

                        // if starting station and Ending station is same, then through error
                        if (chst1 == chst2)
                        {
                            lngErrorNumber = 3;
                        }

                        // if FromStation and End Station Characters are not between A-E Or distance is not integer, through an error
                        if ((chst1 >= 'A' && chst1 <= 'E')
                            && (chst2 >= 'A' && chst2 <= 'E')
                            && (Regex.IsMatch(stdis, @"^\d+$") == true))
                        {
                            intdis = Int16.Parse(stdis);// converting string distance to integer
                            if (intdis <= 0)    // if distance is negative, through an error
                                lngErrorNumber = 4;

                            // if all of the conditions stasified, add Route to Distance Finder instance
                            df.AddRoutes(new Routes(chst1, chst2, intdis));

                        }
                        else
                        {
                            lngErrorNumber = 1;
                        }
                    }
                    else
                    {
                        lngErrorNumber = 2;
                       
                    }
                }

                // Customzse error messages
                if (lngErrorNumber == 1)
                {
                    lblErrorMessage.Text = "Invalid route station entry: Invalid letter or distance input.";

                }
                else if (lngErrorNumber == 2)
                {
                    lblErrorMessage.Text = "Invalid route length";
                }
                else if (lngErrorNumber == 3)
                {
                    lblErrorMessage.Text = "Invalid route station entry: Begin and end station are same.";
                }
                else if (lngErrorNumber == 4)
                {
                    lblErrorMessage.Text = "Invalid route distance entry: Distance can not be less than or equal to zero.";
                }
                else
                {
                    dist = df.FindRouteDistance('A', 'B', 'C');
                    lblOutput1.Text = (dist == 0) ? "NO SUCH ROUTE" : dist.ToString();

                    dist = df.FindRouteDistance('A', 'D');
                    lblOutput2.Text = (dist == 0) ? "NO SUCH ROUTE" : dist.ToString();

                    dist = df.FindRouteDistance('A', 'D', 'C');
                    lblOutput3.Text = (dist == 0) ? "NO SUCH ROUTE" : dist.ToString();

                    dist = df.FindRouteDistance('A', 'E', 'B', 'C', 'D');
                    lblOutput4.Text = (dist == 0) ? "NO SUCH ROUTE" : dist.ToString();

                    dist = df.FindRouteDistance('A', 'E', 'D');
                    lblOutput5.Text = (dist == 0) ? "NO SUCH ROUTE" : dist.ToString();

                    dist = df.RouteCounter('C', 'C',ref cnt);
                    lblOutput6.Text = dist.ToString();

                    //dist = df.StopsCounter('A', 'C');
                    //lblOutput7.Text = dist.ToString();

                    dist = df.DistanceCounter('C', 'C', ref cnt);
                    lblOutput10.Text = dist.ToString();
                }
            }
            catch (Exception ex)
            {
                lblErrorMessage.Text = lblErrorMessage.Text +  ex.Message;
            }
        }

   
    }
}