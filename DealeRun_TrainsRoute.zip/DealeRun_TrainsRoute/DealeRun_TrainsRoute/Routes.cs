﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DealeRun_TrainsRoute
{
    // Routes Class to store info of each individual route. It has property FromStation,ToStation,Distance
    public class Routes
    {
        private char station1;
        private char station2;
        private int distance;
        public Routes(char st1, char st2, int dist)
        {
            station1 = st1;
            station2 = st2;
            distance = dist;
        }

        //Property From Station
        public char FromStation
        {
            get
            {
                return station1;
            }
        }

        //Property To Station
        public char ToStation
        {
            get
            {
                return station2;
            }
        }

        //Property Distance
        public int Distance
        {
            get
            {
                return distance;
            }
        }
       
    }
}